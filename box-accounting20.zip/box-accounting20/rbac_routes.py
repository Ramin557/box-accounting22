from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from functools import wraps
from models import User, Role, Permission, role_permissions
from database import db
from werkzeug.security import generate_password_hash

# Create blueprint
rbac_bp = Blueprint("rbac", __name__, url_prefix="/rbac")

def permission_required(permission_name):
    """Decorator to check if user has specific permission."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("لطفاً برای دسترسی به این صفحه وارد شوید.", "info")
                return redirect(url_for("main.login"))
            if not current_user.has_permission(permission_name):
                flash("شما اجازه دسترسی به این بخش را ندارید.", "danger")
                return redirect(url_for("main.dashboard"))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def role_required(role_name):
    """Decorator to check if user has specific role."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("لطفاً برای دسترسی به این صفحه وارد شوید.", "info")
                return redirect(url_for("main.login"))
            if not current_user.user_role or current_user.user_role.name != role_name:
                flash("شما اجازه دسترسی به این بخش را ندارید.", "danger")
                return redirect(url_for("main.dashboard"))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@rbac_bp.route("/users")
@login_required
@permission_required("view_users")
def users():
    """List all users."""
    users = User.query.all()
    return render_template("rbac/users.html", users=users)

@rbac_bp.route("/users/add", methods=["GET", "POST"])
@login_required
@permission_required("add_user")
def add_user():
    """Add new user."""
    if request.method == "POST":
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")
        full_name = request.form.get("full_name")
        role_id = request.form.get("role_id")

        if not username or not email or not password or not full_name:
            flash("لطفاً تمام فیلدهای الزامی را پر کنید.", "error")
            return redirect(url_for("rbac.add_user"))

        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            flash("نام کاربری یا ایمیل قبلاً ثبت شده است.", "error")
            return redirect(url_for("rbac.add_user"))

        user = User(
            username=username,
            email=email,
            full_name=full_name,
            role_id=role_id if role_id else None
        )
        user.set_password(password)

        try:
            db.session.add(user)
            db.session.commit()
            flash("کاربر با موفقیت اضافه شد.", "success")
            return redirect(url_for("rbac.users"))
        except Exception as e:
            db.session.rollback()
            flash(f"خطا در افزودن کاربر: {e}", "error")

    roles = Role.query.all()
    return render_template("rbac/add_user.html", roles=roles)

@rbac_bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("edit_user")
def edit_user(user_id):
    """Edit user."""
    user = User.query.get_or_404(user_id)

    if request.method == "POST":
        user.username = request.form.get("username")
        user.email = request.form.get("email")
        user.full_name = request.form.get("full_name")
        user.role_id = request.form.get("role_id")
        is_active = request.form.get("is_active")
        user.is_active = True if is_active == "on" else False

        new_password = request.form.get("password")
        if new_password:
            user.set_password(new_password)

        try:
            db.session.commit()
            flash("کاربر با موفقیت ویرایش شد.", "success")
            return redirect(url_for("rbac.users"))
        except Exception as e:
            db.session.rollback()
            flash(f"خطا در ویرایش کاربر: {e}", "error")

    roles = Role.query.all()
    return render_template("rbac/edit_user.html", user=user, roles=roles)

@rbac_bp.route("/users/<int:user_id>/delete", methods=["POST"])
@login_required
@permission_required("delete_user")
def delete_user(user_id):
    """Delete user."""
    user = User.query.get_or_404(user_id)
    try:
        db.session.delete(user)
        db.session.commit()
        flash("کاربر با موفقیت حذف شد.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"خطا در حذف کاربر: {e}", "error")
    return redirect(url_for("rbac.users"))

@rbac_bp.route("/roles")
@login_required
@permission_required("view_roles")
def roles():
    """List all roles."""
    roles = Role.query.all()
    return render_template("rbac/roles.html", roles=roles)

@rbac_bp.route("/roles/add", methods=["GET", "POST"])
@login_required
@permission_required("add_role")
def add_role():
    """Add new role."""
    if request.method == "POST":
        name = request.form.get("name")
        display_name = request.form.get("display_name")
        description = request.form.get("description")
        permission_ids = request.form.getlist("permissions")

        if not name or not display_name:
            flash("لطفاً نام و نام نمایشی نقش را وارد کنید.", "error")
            return redirect(url_for("rbac.add_role"))

        existing_role = Role.query.filter_by(name=name).first()
        if existing_role:
            flash("نقش با این نام قبلاً ثبت شده است.", "error")
            return redirect(url_for("rbac.add_role"))

        role = Role(
            name=name,
            display_name=display_name,
            description=description
        )

        for perm_id in permission_ids:
            permission = Permission.query.get(int(perm_id))
            if permission:
                role.permissions.append(permission)

        try:
            db.session.add(role)
            db.session.commit()
            flash("نقش با موفقیت اضافه شد.", "success")
            return redirect(url_for("rbac.roles"))
        except Exception as e:
            db.session.rollback()
            flash(f"خطا در افزودن نقش: {e}", "error")

    permissions = Permission.query.all()
    return render_template("rbac/add_role.html", permissions=permissions)

@rbac_bp.route("/roles/<int:role_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("edit_role")
def edit_role(role_id):
    """Edit role."""
    role = Role.query.get_or_404(role_id)

    if request.method == "POST":
        role.name = request.form.get("name")
        role.display_name = request.form.get("display_name")
        role.description = request.form.get("description")
        permission_ids = request.form.getlist("permissions")

        # Clear existing permissions and add new ones
        role.permissions = []
        for perm_id in permission_ids:
            permission = Permission.query.get(int(perm_id))
            if permission:
                role.permissions.append(permission)

        try:
            db.session.commit()
            flash("نقش با موفقیت ویرایش شد.", "success")
            return redirect(url_for("rbac.roles"))
        except Exception as e:
            db.session.rollback()
            flash(f"خطا در ویرایش نقش: {e}", "error")

    permissions = Permission.query.all()
    return render_template("rbac/edit_role.html", role=role, permissions=permissions)

@rbac_bp.route("/roles/<int:role_id>/delete", methods=["POST"])
@login_required
@permission_required("delete_role")
def delete_role(role_id):
    """Delete role."""
    role = Role.query.get_or_404(role_id)
    try:
        db.session.delete(role)
        db.session.commit()
        flash("نقش با موفقیت حذف شد.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"خطا در حذف نقش: {e}", "error")
    return redirect(url_for("rbac.roles"))

@rbac_bp.route("/permissions")
@login_required
@permission_required("view_permissions")
def permissions():
    """List all permissions."""
    permissions = Permission.query.all()
    return render_template("rbac/permissions.html", permissions=permissions)

def setup_rbac():
    """Setup initial permissions and roles."""
    
    # Define permissions
    permissions_data = [
        # User Management
        {"name": "view_users", "description": "مشاهده لیست کاربران", "category": "User Management"},
        {"name": "add_user", "description": "افزودن کاربر جدید", "category": "User Management"},
        {"name": "edit_user", "description": "ویرایش اطلاعات کاربر", "category": "User Management"},
        {"name": "delete_user", "description": "حذف کاربر", "category": "User Management"},
        
        # Role Management
        {"name": "view_roles", "description": "مشاهده لیست نقش‌ها", "category": "Role Management"},
        {"name": "add_role", "description": "افزودن نقش جدید", "category": "Role Management"},
        {"name": "edit_role", "description": "ویرایش نقش", "category": "Role Management"},
        {"name": "delete_role", "description": "حذف نقش", "category": "Role Management"},
        
        # Permission Management
        {"name": "view_permissions", "description": "مشاهده لیست مجوزها", "category": "Permission Management"},
        
        # Customer Management
        {"name": "view_customers", "description": "مشاهده لیست مشتریان", "category": "Customer Management"},
        {"name": "add_customer", "description": "افزودن مشتری جدید", "category": "Customer Management"},
        {"name": "edit_customer", "description": "ویرایش مشتری", "category": "Customer Management"},
        {"name": "delete_customer", "description": "حذف مشتری", "category": "Customer Management"},
        
        # Product Management
        {"name": "view_products", "description": "مشاهده لیست محصولات", "category": "Product Management"},
        {"name": "add_product", "description": "افزودن محصول جدید", "category": "Product Management"},
        {"name": "edit_product", "description": "ویرایش محصول", "category": "Product Management"},
        {"name": "delete_product", "description": "حذف محصول", "category": "Product Management"},
        
        # Order Management
        {"name": "view_orders", "description": "مشاهده لیست سفارشات", "category": "Order Management"},
        {"name": "add_order", "description": "افزودن سفارش جدید", "category": "Order Management"},
        {"name": "edit_order", "description": "ویرایش سفارش", "category": "Order Management"},
        {"name": "delete_order", "description": "حذف سفارش", "category": "Order Management"},
        
        # Invoice Management
        {"name": "view_invoices", "description": "مشاهده لیست فاکتورها", "category": "Invoice Management"},
        {"name": "add_invoice", "description": "افزودن فاکتور جدید", "category": "Invoice Management"},
        {"name": "edit_invoice", "description": "ویرایش فاکتور", "category": "Invoice Management"},
        {"name": "delete_invoice", "description": "حذف فاکتور", "category": "Invoice Management"},
        
        # Accounting Management
        {"name": "view_accounts", "description": "مشاهده لیست حساب‌ها", "category": "Accounting Management"},
        {"name": "add_account", "description": "افزودن حساب جدید", "category": "Accounting Management"},
        {"name": "edit_account", "description": "ویرایش حساب", "category": "Accounting Management"},
        {"name": "delete_account", "description": "حذف حساب", "category": "Accounting Management"},
        {"name": "view_transactions", "description": "مشاهده لیست تراکنش‌ها", "category": "Accounting Management"},
        {"name": "add_transaction", "description": "افزودن تراکنش جدید", "category": "Accounting Management"},
        {"name": "edit_transaction", "description": "ویرایش تراکنش", "category": "Accounting Management"},
        {"name": "delete_transaction", "description": "حذف تراکنش", "category": "Accounting Management"},
        {"name": "view_journal_entries", "description": "مشاهده لیست اسناد حسابداری", "category": "Accounting Management"},
        {"name": "add_journal_entry", "description": "افزودن سند حسابداری جدید", "category": "Accounting Management"},
        {"name": "edit_journal_entry", "description": "ویرایش سند حسابداری", "category": "Accounting Management"},
        {"name": "delete_journal_entry", "description": "حذف سند حسابداری", "category": "Accounting Management"},
        
        # Reports
        {"name": "view_reports", "description": "مشاهده گزارشات", "category": "Reports"},
        {"name": "view_sales_report", "description": "مشاهده گزارش فروش", "category": "Reports"},
        {"name": "view_financial_report", "description": "مشاهده گزارش مالی", "category": "Reports"},
    ]

    for perm_data in permissions_data:
        existing_perm = Permission.query.filter_by(name=perm_data["name"]).first()
        if not existing_perm:
            permission = Permission(
                name=perm_data["name"],
                description=perm_data["description"],
                category=perm_data["category"]
            )
            db.session.add(permission)
            db.session.commit()
            print(f"مجوز {permission.name} ایجاد شد.")

    # Define roles
    roles_data = [
        {
            "name": "Super Admin",
            "display_name": "مدیر ارشد",
            "description": "دسترسی کامل به تمام امکانات سیستم",
            "permissions": [
                "view_users", "add_user", "edit_user", "delete_user",
                "view_roles", "add_role", "edit_role", "delete_role",
                "view_permissions",
                "view_customers", "add_customer", "edit_customer", "delete_customer",
                "view_products", "add_product", "edit_product", "delete_product",
                "view_orders", "add_order", "edit_order", "delete_order",
                "view_invoices", "add_invoice", "edit_invoice", "delete_invoice",
                "view_accounts", "add_account", "edit_account", "delete_account",
                "view_transactions", "add_transaction", "edit_transaction", "delete_transaction",
                "view_journal_entries", "add_journal_entry", "edit_journal_entry", "delete_journal_entry",
                "view_reports", "view_sales_report", "view_financial_report"
            ]
        },
        {
            "name": "Admin",
            "display_name": "مدیر",
            "description": "دسترسی مدیریتی به بخش‌های اصلی سیستم",
            "permissions": [
                "view_users", "add_user", "edit_user",
                "view_roles",
                "view_customers", "add_customer", "edit_customer", "delete_customer",
                "view_products", "add_product", "edit_product", "delete_product",
                "view_orders", "add_order", "edit_order", "delete_order",
                "view_invoices", "add_invoice", "edit_invoice", "delete_invoice",
                "view_reports", "view_sales_report", "view_financial_report"
            ]
        },
        {
            "name": "Accountant",
            "display_name": "حسابدار",
            "description": "دسترسی به بخش‌های حسابداری",
            "permissions": [
                "view_customers",
                "view_products",
                "view_orders",
                "view_invoices", "add_invoice", "edit_invoice",
                "view_accounts", "add_account", "edit_account",
                "view_transactions", "add_transaction", "edit_transaction",
                "view_journal_entries", "add_journal_entry", "edit_journal_entry",
                "view_reports", "view_financial_report"
            ]
        },
        {
            "name": "Sales",
            "display_name": "فروش",
            "description": "دسترسی به بخش‌های فروش و مشتریان",
            "permissions": [
                "view_customers", "add_customer", "edit_customer",
                "view_products",
                "view_orders", "add_order", "edit_order",
                "view_invoices", "add_invoice",
                "view_reports", "view_sales_report"
            ]
        },
        {
            "name": "User",
            "display_name": "کاربر عادی",
            "description": "دسترسی محدود به مشاهده اطلاعات",
            "permissions": [
                "view_customers",
                "view_products",
                "view_orders",
                "view_invoices"
            ]
        }
    ]

    for role_data in roles_data:
        existing_role = Role.query.filter_by(name=role_data["name"]).first()
        if not existing_role:
            role = Role(
                name=role_data["name"],
                display_name=role_data["display_name"],
                description=role_data["description"]
            )
            
            for perm_name in role_data["permissions"]:
                permission = Permission.query.filter_by(name=perm_name).first()
                if permission:
                    role.permissions.append(permission)
            
            db.session.add(role)
            db.session.commit()
            print(f"نقش {role.name} ایجاد شد.")




def initialize_rbac_data():
    """Initialize RBAC permissions and roles."""
    # Define permissions
    permissions_data = [
        # User management
        ("view_users", "مشاهده کاربران", "مدیریت کاربران"),
        ("add_user", "افزودن کاربر", "مدیریت کاربران"),
        ("edit_user", "ویرایش کاربر", "مدیریت کاربران"),
        ("delete_user", "حذف کاربر", "مدیریت کاربران"),
        
        # Role management
        ("view_roles", "مشاهده نقش‌ها", "مدیریت نقش‌ها"),
        ("add_role", "افزودن نقش", "مدیریت نقش‌ها"),
        ("edit_role", "ویرایش نقش", "مدیریت نقش‌ها"),
        ("delete_role", "حذف نقش", "مدیریت نقش‌ها"),
        
        # Permission management
        ("view_permissions", "مشاهده مجوزها", "مدیریت مجوزها"),
        
        # Customer management
        ("view_customers", "مشاهده مشتریان", "مدیریت مشتریان"),
        ("add_customer", "افزودن مشتری", "مدیریت مشتریان"),
        ("edit_customer", "ویرایش مشتری", "مدیریت مشتریان"),
        ("delete_customer", "حذف مشتری", "مدیریت مشتریان"),
        
        # Product management
        ("view_products", "مشاهده محصولات", "مدیریت محصولات"),
        ("add_product", "افزودن محصول", "مدیریت محصولات"),
        ("edit_product", "ویرایش محصول", "مدیریت محصولات"),
        ("delete_product", "حذف محصول", "مدیریت محصولات"),
        
        # Order management
        ("view_orders", "مشاهده سفارشات", "مدیریت سفارشات"),
        ("add_order", "افزودن سفارش", "مدیریت سفارشات"),
        ("edit_order", "ویرایش سفارش", "مدیریت سفارشات"),
        ("delete_order", "حذف سفارش", "مدیریت سفارشات"),
        
        # Invoice management
        ("view_invoices", "مشاهده فاکتورها", "مدیریت فاکتورها"),
        ("add_invoice", "افزودن فاکتور", "مدیریت فاکتورها"),
        ("edit_invoice", "ویرایش فاکتور", "مدیریت فاکتورها"),
        ("delete_invoice", "حذف فاکتور", "مدیریت فاکتورها"),
        
        # Account management
        ("view_accounts", "مشاهده حساب‌ها", "مدیریت حساب‌ها"),
        ("add_account", "افزودن حساب", "مدیریت حساب‌ها"),
        ("edit_account", "ویرایش حساب", "مدیریت حساب‌ها"),
        ("delete_account", "حذف حساب", "مدیریت حساب‌ها"),
        
        # Transaction management
        ("view_transactions", "مشاهده تراکنش‌ها", "مدیریت تراکنش‌ها"),
        ("add_transaction", "افزودن تراکنش", "مدیریت تراکنش‌ها"),
        ("edit_transaction", "ویرایش تراکنش", "مدیریت تراکنش‌ها"),
        ("delete_transaction", "حذف تراکنش", "مدیریت تراکنش‌ها"),
        
        # Journal entry management
        ("view_journal_entries", "مشاهده اسناد حسابداری", "مدیریت اسناد حسابداری"),
        ("add_journal_entry", "افزودن سند حسابداری", "مدیریت اسناد حسابداری"),
        ("edit_journal_entry", "ویرایش سند حسابداری", "مدیریت اسناد حسابداری"),
        ("delete_journal_entry", "حذف سند حسابداری", "مدیریت اسناد حسابداری"),
        
        # Reports
        ("view_reports", "مشاهده گزارشات", "گزارشات"),
        ("view_sales_report", "مشاهده گزارش فروش", "گزارشات"),
        ("view_financial_report", "مشاهده گزارش مالی", "گزارشات"),
        
        # Box manufacturing permissions
        ("view_materials", "مشاهده مواد اولیه", "جعبه‌سازی"),
        ("add_material", "افزودن ماده اولیه", "جعبه‌سازی"),
        ("edit_material", "ویرایش ماده اولیه", "جعبه‌سازی"),
        ("delete_material", "حذف ماده اولیه", "جعبه‌سازی"),
        ("view_designs", "مشاهده طرح‌های جعبه", "جعبه‌سازی"),
        ("add_design", "افزودن طرح جعبه", "جعبه‌سازی"),
        ("edit_design", "ویرایش طرح جعبه", "جعبه‌سازی"),
        ("delete_design", "حذف طرح جعبه", "جعبه‌سازی"),
        ("view_custom_orders", "مشاهده سفارشات سفارشی", "جعبه‌سازی"),
        ("add_custom_order", "افزودن سفارش سفارشی", "جعبه‌سازی"),
        ("edit_custom_order", "ویرایش سفارش سفارشی", "جعبه‌سازی"),
        ("delete_custom_order", "حذف سفارش سفارشی", "جعبه‌سازی"),
        ("view_quality_control", "مشاهده کنترل کیفیت", "جعبه‌سازی"),
        ("add_quality_control", "افزودن کنترل کیفیت", "جعبه‌سازی"),
        ("view_machinery", "مشاهده ماشین‌آلات", "جعبه‌سازی"),
        ("add_machinery", "افزودن ماشین‌آلات", "جعبه‌سازی"),
        ("edit_machinery", "ویرایش ماشین‌آلات", "جعبه‌سازی"),
        ("view_production_schedule", "مشاهده برنامه تولید", "جعبه‌سازی"),
        ("add_production_schedule", "افزودن برنامه تولید", "جعبه‌سازی"),
        ("view_stock_management", "مشاهده مدیریت انبار", "جعبه‌سازی"),
        ("add_stock_movement", "افزودن حرکت انبار", "جعبه‌سازی"),
    ]
    
    # Create permissions
    created_permissions = {}
    for perm_name, display_name, category in permissions_data:
        permission = Permission.query.filter_by(name=perm_name).first()
        if not permission:
            permission = Permission(
                name=perm_name,
                display_name=display_name,
                category=category
            )
            db.session.add(permission)
            print(f"مجوز {display_name} ایجاد شد.")
        created_permissions[perm_name] = permission
    
    db.session.commit()
    
    # Define roles and their permissions
    roles_data = [
        ("Super Admin", "مدیر کل", "دسترسی کامل به تمام بخش‌ها", list(created_permissions.keys())),
        ("Admin", "مدیر", "دسترسی مدیریتی", [
            "view_users", "add_user", "edit_user",
            "view_customers", "add_customer", "edit_customer", "delete_customer",
            "view_products", "add_product", "edit_product", "delete_product",
            "view_orders", "add_order", "edit_order", "delete_order",
            "view_invoices", "add_invoice", "edit_invoice", "delete_invoice",
            "view_accounts", "add_account", "edit_account",
            "view_transactions", "add_transaction", "edit_transaction",
            "view_reports", "view_sales_report", "view_financial_report",
            "view_materials", "add_material", "edit_material",
            "view_designs", "add_design", "edit_design",
            "view_custom_orders", "add_custom_order", "edit_custom_order",
            "view_quality_control", "add_quality_control",
            "view_machinery", "add_machinery", "edit_machinery",
            "view_production_schedule", "add_production_schedule",
            "view_stock_management", "add_stock_movement"
        ]),
        ("Accountant", "حسابدار", "دسترسی به بخش‌های مالی", [
            "view_customers", "add_customer", "edit_customer",
            "view_invoices", "add_invoice", "edit_invoice",
            "view_accounts", "add_account", "edit_account",
            "view_transactions", "add_transaction", "edit_transaction",
            "view_journal_entries", "add_journal_entry", "edit_journal_entry",
            "view_reports", "view_sales_report", "view_financial_report"
        ]),
        ("Sales", "فروش", "دسترسی به بخش فروش", [
            "view_customers", "add_customer", "edit_customer",
            "view_products", "view_orders", "add_order", "edit_order",
            "view_invoices", "add_invoice",
            "view_reports", "view_sales_report",
            "view_designs", "add_design",
            "view_custom_orders", "add_custom_order", "edit_custom_order"
        ]),
        ("Production", "تولید", "دسترسی به بخش تولید", [
            "view_materials", "view_designs",
            "view_custom_orders", "edit_custom_order",
            "view_quality_control", "add_quality_control",
            "view_machinery", "view_production_schedule", "add_production_schedule",
            "view_stock_management", "add_stock_movement"
        ]),
        ("User", "کاربر", "دسترسی محدود", [
            "view_customers", "view_products", "view_orders", "view_invoices"
        ])
    ]
    
    # Create roles
    for role_name, display_name, description, permission_names in roles_data:
        role = Role.query.filter_by(name=role_name).first()
        if not role:
            role = Role(
                name=role_name,
                display_name=display_name,
                description=description
            )
            db.session.add(role)
            db.session.flush()  # Get the role ID
            
            # Assign permissions to role
            for perm_name in permission_names:
                if perm_name in created_permissions:
                    role.permissions.append(created_permissions[perm_name])
            
            print(f"نقش {display_name} ایجاد شد.")
    
    db.session.commit()

