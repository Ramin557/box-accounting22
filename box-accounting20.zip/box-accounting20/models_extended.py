from database import db
from datetime import datetime
from sqlalchemy import Enum
import enum

# Enums for box manufacturing
class BoxType(enum.Enum):
    SINGLE_WALL = "single_wall"
    DOUBLE_WALL = "double_wall"
    TRIPLE_WALL = "triple_wall"

class MaterialType(enum.Enum):
    CARDBOARD = "cardboard"
    CORRUGATED = "corrugated"
    KRAFT = "kraft"
    RECYCLED = "recycled"

class OrderStatus(enum.Enum):
    PENDING = "pending"
    DESIGN_APPROVAL = "design_approval"
    IN_PRODUCTION = "in_production"
    QUALITY_CHECK = "quality_check"
    COMPLETED = "completed"
    SHIPPED = "shipped"

class QualityStatus(enum.Enum):
    PASSED = "passed"
    FAILED = "failed"
    PENDING = "pending"

# Raw Materials Model
class RawMaterial(db.Model):
    __tablename__ = 'raw_materials'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    material_type = db.Column(Enum(MaterialType), nullable=False)
    thickness = db.Column(db.Float, nullable=False)  # in mm
    width = db.Column(db.Float, nullable=False)  # in cm
    length = db.Column(db.Float, nullable=False)  # in cm
    weight_per_sqm = db.Column(db.Float, nullable=False)  # kg per square meter
    cost_per_sqm = db.Column(db.Numeric(10, 2), nullable=False)
    current_stock = db.Column(db.Float, default=0)  # in square meters
    minimum_stock = db.Column(db.Float, default=0)
    supplier_id = db.Column(db.Integer, db.ForeignKey('customers.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    supplier = db.relationship('Customer', backref='supplied_materials')
    
    def __repr__(self):
        return f'<RawMaterial {self.name}>'

# Box Design Model
class BoxDesign(db.Model):
    __tablename__ = 'box_designs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    box_type = db.Column(Enum(BoxType), nullable=False)
    length = db.Column(db.Float, nullable=False)  # in cm
    width = db.Column(db.Float, nullable=False)   # in cm
    height = db.Column(db.Float, nullable=False)  # in cm
    material_id = db.Column(db.Integer, db.ForeignKey('raw_materials.id'), nullable=False)
    
    # Calculated fields
    surface_area = db.Column(db.Float)  # calculated surface area
    material_needed = db.Column(db.Float)  # square meters needed
    
    # Design specifications
    print_colors = db.Column(db.Integer, default=1)  # number of colors
    has_logo = db.Column(db.Boolean, default=False)
    has_window = db.Column(db.Boolean, default=False)
    special_coating = db.Column(db.String(50))
    
    # Files
    design_file_path = db.Column(db.String(255))
    technical_drawing_path = db.Column(db.String(255))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    customer = db.relationship('Customer', backref='box_designs')
    material = db.relationship('RawMaterial', backref='designs')
    
    def calculate_surface_area(self):
        """Calculate the surface area needed for the box"""
        # Basic calculation for a rectangular box
        # This is a simplified calculation - in reality, it would be more complex
        area = 2 * (self.length * self.width + self.length * self.height + self.width * self.height)
        # Add 10% for waste and cutting
        self.surface_area = area * 1.1
        self.material_needed = self.surface_area / 10000  # convert cm² to m²
        return self.surface_area
    
    def __repr__(self):
        return f'<BoxDesign {self.name}>'

# Production Cost Model
class ProductionCost(db.Model):
    __tablename__ = 'production_costs'
    
    id = db.Column(db.Integer, primary_key=True)
    design_id = db.Column(db.Integer, db.ForeignKey('box_designs.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    
    # Cost breakdown
    material_cost = db.Column(db.Numeric(10, 2), default=0)
    printing_cost = db.Column(db.Numeric(10, 2), default=0)
    cutting_cost = db.Column(db.Numeric(10, 2), default=0)
    labor_cost = db.Column(db.Numeric(10, 2), default=0)
    overhead_cost = db.Column(db.Numeric(10, 2), default=0)
    total_cost = db.Column(db.Numeric(10, 2), default=0)
    
    # Pricing
    profit_margin = db.Column(db.Float, default=0.2)  # 20% default
    unit_price = db.Column(db.Numeric(10, 2), default=0)
    total_price = db.Column(db.Numeric(10, 2), default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    design = db.relationship('BoxDesign', backref='cost_calculations')
    
    def calculate_costs(self):
        """Calculate all production costs"""
        # Material cost
        self.material_cost = self.design.material_needed * self.design.material.cost_per_sqm * self.quantity
        
        # Printing cost (per color per unit)
        self.printing_cost = self.design.print_colors * 0.5 * self.quantity
        
        # Cutting cost (per unit)
        self.cutting_cost = 0.3 * self.quantity
        
        # Labor cost (estimated per unit)
        self.labor_cost = 1.0 * self.quantity
        
        # Overhead cost (10% of direct costs)
        direct_costs = self.material_cost + self.printing_cost + self.cutting_cost + self.labor_cost
        self.overhead_cost = direct_costs * 0.1
        
        # Total cost
        self.total_cost = direct_costs + self.overhead_cost
        
        # Pricing
        self.unit_price = (self.total_cost / self.quantity) * (1 + self.profit_margin)
        self.total_price = self.unit_price * self.quantity
        
        return self.total_cost
    
    def __repr__(self):
        return f'<ProductionCost for {self.design.name}>'

# Custom Order Model (extends Order)
class CustomOrder(db.Model):
    __tablename__ = 'custom_orders'
    
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    design_id = db.Column(db.Integer, db.ForeignKey('box_designs.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    
    # Production details
    status = db.Column(Enum(OrderStatus), default=OrderStatus.PENDING)
    estimated_completion = db.Column(db.DateTime)
    actual_completion = db.Column(db.DateTime)
    
    # Production tracking
    design_approved = db.Column(db.Boolean, default=False)
    design_approved_at = db.Column(db.DateTime)
    production_started = db.Column(db.DateTime)
    quality_checked = db.Column(db.Boolean, default=False)
    quality_checked_at = db.Column(db.DateTime)
    
    # Special requirements
    rush_order = db.Column(db.Boolean, default=False)
    special_instructions = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    order = db.relationship('Order', backref='custom_details')
    design = db.relationship('BoxDesign', backref='custom_orders')
    
    def __repr__(self):
        return f'<CustomOrder {self.id}>'

# Quality Control Model
class QualityControl(db.Model):
    __tablename__ = 'quality_controls'
    
    id = db.Column(db.Integer, primary_key=True)
    custom_order_id = db.Column(db.Integer, db.ForeignKey('custom_orders.id'), nullable=False)
    inspector_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Quality metrics
    dimension_accuracy = db.Column(db.Boolean, default=True)
    print_quality = db.Column(db.Boolean, default=True)
    material_integrity = db.Column(db.Boolean, default=True)
    overall_appearance = db.Column(db.Boolean, default=True)
    
    # Results
    status = db.Column(Enum(QualityStatus), default=QualityStatus.PENDING)
    defect_count = db.Column(db.Integer, default=0)
    defect_description = db.Column(db.Text)
    corrective_action = db.Column(db.Text)
    
    # Timestamps
    inspection_date = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    custom_order = db.relationship('CustomOrder', backref='quality_checks')
    inspector = db.relationship('User', backref='quality_inspections')
    
    def __repr__(self):
        return f'<QualityControl {self.id}>'

# Machinery Model
class Machinery(db.Model):
    __tablename__ = 'machinery'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    machine_type = db.Column(db.String(50), nullable=False)  # cutting, printing, folding, etc.
    manufacturer = db.Column(db.String(100))
    model = db.Column(db.String(100))
    serial_number = db.Column(db.String(100))
    
    # Specifications
    max_sheet_size = db.Column(db.String(50))  # e.g., "100x70 cm"
    production_speed = db.Column(db.Integer)  # units per hour
    power_consumption = db.Column(db.Float)  # kW
    
    # Financial
    purchase_date = db.Column(db.Date)
    purchase_cost = db.Column(db.Numeric(12, 2))
    depreciation_rate = db.Column(db.Float, default=0.1)  # 10% per year
    
    # Maintenance
    last_maintenance = db.Column(db.Date)
    next_maintenance = db.Column(db.Date)
    maintenance_interval = db.Column(db.Integer, default=90)  # days
    
    # Status
    is_operational = db.Column(db.Boolean, default=True)
    current_efficiency = db.Column(db.Float, default=1.0)  # 0-1 scale
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Machinery {self.name}>'

# Production Schedule Model
class ProductionSchedule(db.Model):
    __tablename__ = 'production_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    custom_order_id = db.Column(db.Integer, db.ForeignKey('custom_orders.id'), nullable=False)
    machinery_id = db.Column(db.Integer, db.ForeignKey('machinery.id'), nullable=False)
    
    # Schedule details
    scheduled_start = db.Column(db.DateTime, nullable=False)
    scheduled_end = db.Column(db.DateTime, nullable=False)
    actual_start = db.Column(db.DateTime)
    actual_end = db.Column(db.DateTime)
    
    # Production details
    planned_quantity = db.Column(db.Integer, nullable=False)
    actual_quantity = db.Column(db.Integer, default=0)
    waste_quantity = db.Column(db.Integer, default=0)
    
    # Status
    status = db.Column(db.String(20), default='scheduled')  # scheduled, in_progress, completed, cancelled
    notes = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    custom_order = db.relationship('CustomOrder', backref='production_schedules')
    machinery = db.relationship('Machinery', backref='schedules')
    
    def __repr__(self):
        return f'<ProductionSchedule {self.id}>'

# Stock Movement Model for Raw Materials
class StockMovement(db.Model):
    __tablename__ = 'stock_movements'
    
    id = db.Column(db.Integer, primary_key=True)
    material_id = db.Column(db.Integer, db.ForeignKey('raw_materials.id'), nullable=False)
    movement_type = db.Column(db.String(20), nullable=False)  # 'in', 'out', 'adjustment'
    quantity = db.Column(db.Float, nullable=False)  # can be negative for outgoing
    reference_type = db.Column(db.String(50))  # 'purchase', 'production', 'adjustment'
    reference_id = db.Column(db.Integer)  # ID of related record
    
    # Details
    unit_cost = db.Column(db.Numeric(10, 2))
    total_cost = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    
    # Tracking
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    material = db.relationship('RawMaterial', backref='stock_movements')
    created_by_user = db.relationship('User', backref='stock_movements')
    
    def __repr__(self):
        return f'<StockMovement {self.material.name}: {self.quantity}>'

