from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import Customer, Product, Order, Invoice
from models_extended import (
    RawMaterial, BoxDesign, ProductionCost, CustomOrder, QualityControl,
    Machinery, ProductionSchedule, StockMovement, MaterialType, BoxType,
    OrderStatus, QualityStatus
)
from database import db
from datetime import datetime, timedelta
import json

# Create blueprint for box manufacturing features
box_bp = Blueprint("box", __name__, url_prefix="/box")

# Raw Materials Management
@box_bp.route("/materials")
@login_required
def materials():
    """Raw materials management page."""
    materials = RawMaterial.query.filter_by(is_active=True).all()
    low_stock_materials = RawMaterial.query.filter(
        RawMaterial.current_stock <= RawMaterial.minimum_stock,
        RawMaterial.is_active == True
    ).all()
    
    return render_template("box/materials.html", 
                         materials=materials,
                         low_stock_materials=low_stock_materials,
                         material_types=MaterialType)

@box_bp.route("/materials/add", methods=["GET", "POST"])
@login_required
def add_material():
    """Add new raw material."""
    if request.method == "POST":
        material = RawMaterial(
            name=request.form.get("name"),
            material_type=MaterialType(request.form.get("material_type")),
            thickness=float(request.form.get("thickness")),
            width=float(request.form.get("width")),
            length=float(request.form.get("length")),
            weight_per_sqm=float(request.form.get("weight_per_sqm")),
            cost_per_sqm=float(request.form.get("cost_per_sqm")),
            current_stock=float(request.form.get("current_stock", 0)),
            minimum_stock=float(request.form.get("minimum_stock", 0)),
            supplier_id=request.form.get("supplier_id") or None
        )
        
        db.session.add(material)
        db.session.commit()
        
        flash("ماده اولیه با موفقیت اضافه شد.", "success")
        return redirect(url_for("box.materials"))
    
    suppliers = Customer.query.filter_by(is_active=True).all()
    return render_template("box/add_material.html", 
                         material_types=MaterialType,
                         suppliers=suppliers)

# Box Design Management
@box_bp.route("/designs")
@login_required
def designs():
    """Box designs management page."""
    designs = BoxDesign.query.filter_by(is_active=True).all()
    return render_template("box/designs.html", designs=designs)

@box_bp.route("/designs/add", methods=["GET", "POST"])
@login_required
def add_design():
    """Add new box design."""
    if request.method == "POST":
        design = BoxDesign(
            name=request.form.get("name"),
            customer_id=int(request.form.get("customer_id")),
            box_type=BoxType(request.form.get("box_type")),
            length=float(request.form.get("length")),
            width=float(request.form.get("width")),
            height=float(request.form.get("height")),
            material_id=int(request.form.get("material_id")),
            print_colors=int(request.form.get("print_colors", 1)),
            has_logo=bool(request.form.get("has_logo")),
            has_window=bool(request.form.get("has_window")),
            special_coating=request.form.get("special_coating")
        )
        
        # Calculate surface area
        design.calculate_surface_area()
        
        db.session.add(design)
        db.session.commit()
        
        flash("طرح جعبه با موفقیت اضافه شد.", "success")
        return redirect(url_for("box.designs"))
    
    customers = Customer.query.filter_by(is_active=True).all()
    materials = RawMaterial.query.filter_by(is_active=True).all()
    return render_template("box/add_design.html", 
                         customers=customers,
                         materials=materials,
                         box_types=BoxType)

# Production Cost Calculator
@box_bp.route("/designs/<int:design_id>/cost", methods=["GET", "POST"])
@login_required
def calculate_cost(design_id):
    """Calculate production cost for a design."""
    design = BoxDesign.query.get_or_404(design_id)
    
    if request.method == "POST":
        quantity = int(request.form.get("quantity"))
        profit_margin = float(request.form.get("profit_margin", 0.2))
        
        # Check if cost calculation already exists
        cost_calc = ProductionCost.query.filter_by(
            design_id=design_id,
            quantity=quantity
        ).first()
        
        if not cost_calc:
            cost_calc = ProductionCost(
                design_id=design_id,
                quantity=quantity,
                profit_margin=profit_margin
            )
            db.session.add(cost_calc)
        else:
            cost_calc.profit_margin = profit_margin
        
        cost_calc.calculate_costs()
        db.session.commit()
        
        return jsonify({
            "success": True,
            "cost_breakdown": {
                "material_cost": float(cost_calc.material_cost),
                "printing_cost": float(cost_calc.printing_cost),
                "cutting_cost": float(cost_calc.cutting_cost),
                "labor_cost": float(cost_calc.labor_cost),
                "overhead_cost": float(cost_calc.overhead_cost),
                "total_cost": float(cost_calc.total_cost),
                "unit_price": float(cost_calc.unit_price),
                "total_price": float(cost_calc.total_price)
            }
        })
    
    return render_template("box/cost_calculator.html", design=design)

# Custom Orders Management
@box_bp.route("/orders")
@login_required
def custom_orders():
    """Custom orders management page."""
    orders = CustomOrder.query.join(Order).all()
    return render_template("box/custom_orders.html", orders=orders)

@box_bp.route("/orders/add", methods=["GET", "POST"])
@login_required
def add_custom_order():
    """Add new custom order."""
    if request.method == "POST":
        # First create the base order
        order = Order(
            customer_id=int(request.form.get("customer_id")),
            order_date=datetime.utcnow(),
            total_amount=0,  # Will be calculated later
            status="Pending"
        )
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Create custom order details
        custom_order = CustomOrder(
            order_id=order.id,
            design_id=int(request.form.get("design_id")),
            quantity=int(request.form.get("quantity")),
            rush_order=bool(request.form.get("rush_order")),
            special_instructions=request.form.get("special_instructions")
        )
        
        # Calculate estimated completion
        days_to_complete = 7  # Default
        if custom_order.rush_order:
            days_to_complete = 3
        custom_order.estimated_completion = datetime.utcnow() + timedelta(days=days_to_complete)
        
        db.session.add(custom_order)
        
        # Calculate and update order total
        cost_calc = ProductionCost.query.filter_by(
            design_id=custom_order.design_id,
            quantity=custom_order.quantity
        ).first()
        
        if cost_calc:
            order.total_amount = cost_calc.total_price
        
        db.session.commit()
        
        flash("سفارش سفارشی با موفقیت ثبت شد.", "success")
        return redirect(url_for("box.custom_orders"))
    
    customers = Customer.query.filter_by(is_active=True).all()
    designs = BoxDesign.query.filter_by(is_active=True).all()
    return render_template("box/add_custom_order.html", 
                         customers=customers,
                         designs=designs)

# Quality Control
@box_bp.route("/quality")
@login_required
def quality_control():
    """Quality control management page."""
    quality_checks = QualityControl.query.all()
    pending_orders = CustomOrder.query.filter_by(
        status=OrderStatus.IN_PRODUCTION,
        quality_checked=False
    ).all()
    
    return render_template("box/quality_control.html", 
                         quality_checks=quality_checks,
                         pending_orders=pending_orders)

@box_bp.route("/quality/check/<int:order_id>", methods=["GET", "POST"])
@login_required
def quality_check(order_id):
    """Perform quality check on an order."""
    custom_order = CustomOrder.query.get_or_404(order_id)
    
    if request.method == "POST":
        quality_check = QualityControl(
            custom_order_id=order_id,
            inspector_id=current_user.id,
            dimension_accuracy=bool(request.form.get("dimension_accuracy")),
            print_quality=bool(request.form.get("print_quality")),
            material_integrity=bool(request.form.get("material_integrity")),
            overall_appearance=bool(request.form.get("overall_appearance")),
            defect_count=int(request.form.get("defect_count", 0)),
            defect_description=request.form.get("defect_description"),
            corrective_action=request.form.get("corrective_action")
        )
        
        # Determine overall status
        all_passed = all([
            quality_check.dimension_accuracy,
            quality_check.print_quality,
            quality_check.material_integrity,
            quality_check.overall_appearance
        ])
        
        quality_check.status = QualityStatus.PASSED if all_passed else QualityStatus.FAILED
        
        # Update custom order
        custom_order.quality_checked = True
        custom_order.quality_checked_at = datetime.utcnow()
        
        if quality_check.status == QualityStatus.PASSED:
            custom_order.status = OrderStatus.COMPLETED
        
        db.session.add(quality_check)
        db.session.commit()
        
        flash("بررسی کیفیت با موفقیت ثبت شد.", "success")
        return redirect(url_for("box.quality_control"))
    
    return render_template("box/quality_check.html", custom_order=custom_order)

# Machinery Management
@box_bp.route("/machinery")
@login_required
def machinery():
    """Machinery management page."""
    machines = Machinery.query.all()
    
    # Calculate machines needing maintenance
    today = datetime.utcnow().date()
    maintenance_due = Machinery.query.filter(
        Machinery.next_maintenance <= today
    ).all()
    
    return render_template("box/machinery.html", 
                         machines=machines,
                         maintenance_due=maintenance_due)

@box_bp.route("/machinery/add", methods=["GET", "POST"])
@login_required
def add_machinery():
    """Add new machinery."""
    if request.method == "POST":
        machine = Machinery(
            name=request.form.get("name"),
            machine_type=request.form.get("machine_type"),
            manufacturer=request.form.get("manufacturer"),
            model=request.form.get("model"),
            serial_number=request.form.get("serial_number"),
            max_sheet_size=request.form.get("max_sheet_size"),
            production_speed=int(request.form.get("production_speed", 0)),
            power_consumption=float(request.form.get("power_consumption", 0)),
            purchase_date=datetime.strptime(request.form.get("purchase_date"), "%Y-%m-%d").date(),
            purchase_cost=float(request.form.get("purchase_cost", 0)),
            maintenance_interval=int(request.form.get("maintenance_interval", 90))
        )
        
        # Calculate next maintenance
        machine.next_maintenance = machine.purchase_date + timedelta(days=machine.maintenance_interval)
        
        db.session.add(machine)
        db.session.commit()
        
        flash("ماشین‌آلات با موفقیت اضافه شد.", "success")
        return redirect(url_for("box.machinery"))
    
    return render_template("box/add_machinery.html")

# Production Schedule
@box_bp.route("/schedule")
@login_required
def production_schedule():
    """Production schedule page."""
    schedules = ProductionSchedule.query.filter(
        ProductionSchedule.scheduled_start >= datetime.utcnow() - timedelta(days=7)
    ).all()
    
    return render_template("box/production_schedule.html", schedules=schedules)

# Stock Management
@box_bp.route("/stock")
@login_required
def stock_management():
    """Stock management page."""
    materials = RawMaterial.query.filter_by(is_active=True).all()
    recent_movements = StockMovement.query.order_by(
        StockMovement.created_at.desc()
    ).limit(20).all()
    
    return render_template("box/stock_management.html", 
                         materials=materials,
                         recent_movements=recent_movements)

@box_bp.route("/stock/movement", methods=["POST"])
@login_required
def add_stock_movement():
    """Add stock movement."""
    movement = StockMovement(
        material_id=int(request.form.get("material_id")),
        movement_type=request.form.get("movement_type"),
        quantity=float(request.form.get("quantity")),
        reference_type=request.form.get("reference_type"),
        unit_cost=float(request.form.get("unit_cost", 0)),
        notes=request.form.get("notes"),
        created_by=current_user.id
    )
    
    movement.total_cost = movement.quantity * movement.unit_cost
    
    # Update material stock
    material = RawMaterial.query.get(movement.material_id)
    if movement.movement_type == "in":
        material.current_stock += movement.quantity
    elif movement.movement_type == "out":
        material.current_stock -= movement.quantity
    else:  # adjustment
        material.current_stock = movement.quantity
    
    db.session.add(movement)
    db.session.commit()
    
    flash("حرکت انبار با موفقیت ثبت شد.", "success")
    return redirect(url_for("box.stock_management"))

# Reports
@box_bp.route("/reports")
@login_required
def reports():
    """Box manufacturing reports."""
    # Material usage report
    material_usage = db.session.query(
        RawMaterial.name,
        db.func.sum(StockMovement.quantity).label('total_used')
    ).join(StockMovement).filter(
        StockMovement.movement_type == 'out',
        StockMovement.created_at >= datetime.utcnow() - timedelta(days=30)
    ).group_by(RawMaterial.name).all()
    
    # Production summary
    production_summary = db.session.query(
        db.func.count(CustomOrder.id).label('total_orders'),
        db.func.sum(CustomOrder.quantity).label('total_quantity'),
        db.func.avg(ProductionCost.unit_price).label('avg_unit_price')
    ).join(ProductionCost).filter(
        CustomOrder.created_at >= datetime.utcnow() - timedelta(days=30)
    ).first()
    
    # Quality metrics
    quality_metrics = db.session.query(
        QualityControl.status,
        db.func.count(QualityControl.id).label('count')
    ).filter(
        QualityControl.inspection_date >= datetime.utcnow() - timedelta(days=30)
    ).group_by(QualityControl.status).all()
    
    return render_template("box/reports.html", 
                         material_usage=material_usage,
                         production_summary=production_summary,
                         quality_metrics=quality_metrics)

# API endpoints for AJAX requests
@box_bp.route("/api/design/<int:design_id>/details")
@login_required
def get_design_details(design_id):
    """Get design details for cost calculation."""
    design = BoxDesign.query.get_or_404(design_id)
    return jsonify({
        "name": design.name,
        "dimensions": f"{design.length}×{design.width}×{design.height} cm",
        "material": design.material.name,
        "surface_area": design.surface_area,
        "material_needed": design.material_needed
    })

@box_bp.route("/api/materials/low-stock")
@login_required
def get_low_stock_materials():
    """Get materials with low stock."""
    materials = RawMaterial.query.filter(
        RawMaterial.current_stock <= RawMaterial.minimum_stock,
        RawMaterial.is_active == True
    ).all()
    
    return jsonify([{
        "id": m.id,
        "name": m.name,
        "current_stock": m.current_stock,
        "minimum_stock": m.minimum_stock
    } for m in materials])

