import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from models import User
from werkzeug.security import generate_password_hash

def create_admin():
    """Create admin user if it doesn't exist."""
    app = create_app()
    
    with app.app_context():
        # Check if admin user exists
        admin_user = User.query.filter_by(username='admin').first()
        if admin_user:
            print('✅ کاربر admin از قبل وجود دارد.')
            return
        
        # Create admin user
        admin_user = User(
            username='admin',
            email='admin@example.com',
            full_name='مدیر سیستم',
            role='admin',
            is_active=True
        )
        admin_user.set_password('admin123')
        
        try:
            db.session.add(admin_user)
            db.session.commit()
            print('✅ کاربر admin با موفقیت ایجاد شد')
            print('📋 اطلاعات ورود:')
            print('   نام کاربری: admin')
            print('   رمز عبور: admin123')
        except Exception as e:
            db.session.rollback()
            print(f'❌ خطا در ایجاد کاربر admin: {e}')

if __name__ == '__main__':
    create_admin()

