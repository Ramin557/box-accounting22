import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_migrate import Migrate
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
login_manager = LoginManager()
csrf = CSRFProtect()
migrate = Migrate()

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.secret_key = os.environ.get("SECRET_KEY", "your-secret-key-for-development")
    app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

    # Ensure the instance folder exists
    instance_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), "instance")
    try:
        os.makedirs(instance_path)
    except OSError:
        pass

    # Configure the database - Use SQLite for now
    database_url = "sqlite:///" + os.path.join(instance_path, "accounting.db")
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    print(f"Database URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    login_manager.login_view = 'main.login'
    login_manager.login_message = 'لطفاً برای دسترسی به این صفحه وارد شوید.'
    login_manager.login_message_category = 'info'

    # Import models here after db is initialized
    from . import models

    @login_manager.user_loader
    def load_user(user_id):
        return models.User.query.get(int(user_id))

    with app.app_context():
        # Create all tables
        db.create_all()

        # Register blueprints
        from .routes import main_bp
        from .rbac_routes import rbac_bp
        app.register_blueprint(main_bp)
        app.register_blueprint(rbac_bp)

        # Setup RBAC data (permissions and roles) and create admin user
        from .rbac_routes import setup_rbac
        setup_rbac()

        # Create admin user if it doesn't exist
        admin_user = models.User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_role = models.Role.query.filter_by(name='Super Admin').first()
            if not admin_role:
                admin_role = models.Role(
                    name='Super Admin',
                    display_name='مدیر ارشد',
                    description='دسترسی کامل به تمام امکانات سیستم',
                    is_system_role=True
                )
                db.session.add(admin_role)
                db.session.commit()
                admin_role = models.Role.query.filter_by(name='Super Admin').first() # Re-fetch after commit

            admin_user = models.User(
                username='admin',
                email='admin@example.com',
                full_name='مدیر سیستم',
                role_id=admin_role.id if admin_role else None,
                is_active=True
            )
            admin_user.set_password('admin123')
            
            try:
                db.session.add(admin_user)
                db.session.commit()
                print('✅ کاربر admin با موفقیت ایجاد شد')
                print('📋 اطلاعات ورود:')
                print('   نام کاربری: admin')
                print('   رمز عبور: admin123')
            except Exception as e:
                db.session.rollback()
                print(f'❌ خطا در ایجاد کاربر admin: {e}')
        else:
            print('✅ کاربر admin از قبل وجود دارد.')

    return app


