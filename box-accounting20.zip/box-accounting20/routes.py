from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from models import User, Customer, Product, Order, Invoice, Account, Transaction, Role, Permission

# Create blueprint
main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def index():
    """Home page redirect to dashboard or login."""
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("main.login"))

@main_bp.route("/login", methods=["GET", "POST"])
def login():
    """Login page."""
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            flash("ورود با موفقیت انجام شد.", "success")
            return redirect(url_for("main.dashboard"))
        else:
            flash("نام کاربری یا رمز عبور اشتباه است.", "danger")

    return render_template("login_page.html")

@main_bp.route("/dashboard")
@login_required
def dashboard():
    """Dashboard page."""
    # Example data for dashboard - replace with actual data from your models
    dashboard_data = {
        "total_customers": Customer.query.count(),
        "total_products": Product.query.count(),
        "total_orders": Order.query.count(),
        "total_invoices": Invoice.query.count(),
        "total_accounts": Account.query.count(),
        "total_transactions": Transaction.query.count(),
        "recent_orders": Order.query.order_by(Order.order_date.desc()).limit(5).all(),
        "recent_invoices": Invoice.query.order_by(Invoice.invoice_date.desc()).limit(5).all(),
    }
    return render_template("dashboard_page.html", dashboard_data=dashboard_data)

@main_bp.route("/logout")
@login_required
def logout():
    """Logout user."""
    logout_user()
    flash("شما با موفقیت از سیستم خارج شدید.", "info")
    return redirect(url_for("main.login"))

# Error Handlers
@main_bp.app_errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

@main_bp.app_errorhandler(500)
def internal_server_error(e):
    return render_template("500.html"), 500

# Example route for customers (requires permission)
@main_bp.route("/customers")
@login_required
# @permission_required("view_customers") # Uncomment when permission_required is available
def customers():
    customers = Customer.query.all()
    return render_template("customers.html", customers=customers)

# Example route for products (requires permission)
@main_bp.route("/products")
@login_required
# @permission_required("view_products") # Uncomment when permission_required is available
def products():
    products = Product.query.all()
    return render_template("products.html", products=products)

# Example route for orders (requires permission)
@main_bp.route("/orders")
@login_required
# @permission_required("view_orders") # Uncomment when permission_required is available
def orders():
    orders = Order.query.all()
    return render_template("orders.html", orders=orders)

# Example route for invoices (requires permission)
@main_bp.route("/invoices")
@login_required
# @permission_required("view_invoices") # Uncomment when permission_required is available
def invoices():
    invoices = Invoice.query.all()
    return render_template("invoices.html", invoices=invoices)

# Example route for accounts (requires permission)
@main_bp.route("/accounts")
@login_required
# @permission_required("view_accounts") # Uncomment when permission_required is available
def accounts():
    accounts = Account.query.all()
    return render_template("accounts.html", accounts=accounts)

# Example route for transactions (requires permission)
@main_bp.route("/transactions")
@login_required
# @permission_required("view_transactions") # Uncomment when permission_required is available
def transactions():
    transactions = Transaction.query.all()
    return render_template("transactions.html", transactions=transactions)

# Example route for journal entries (requires permission)
@main_bp.route("/journal_entries")
@login_required
# @permission_required("view_journal_entries") # Uncomment when permission_required is available
def journal_entries():
    journal_entries = [] # Replace with actual data
    return render_template("journal_entries.html", journal_entries=journal_entries)

# Example route for reports (requires permission)
@main_bp.route("/reports")
@login_required
# @permission_required("view_reports") # Uncomment when permission_required is available
def reports():
    return render_template("reports.html")


