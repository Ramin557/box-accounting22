import os
from flask import Flask
from flask_login import LoginManager
from database import db
from datetime import datetime

def create_app():
    """Create and configure Flask application."""
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here-change-in-production')
    
    # Database configuration
    basedir = os.path.abspath(os.path.dirname(__file__))
    instance_path = os.path.join(basedir, 'instance')
    os.makedirs(instance_path, exist_ok=True)
    
    database_path = os.path.join(instance_path, 'accounting.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{database_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    print(f"Database URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
    
    # Initialize extensions
    db.init_app(app)
    
    # Initialize Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'
    login_manager.login_message = 'لطفاً برای دسترسی به این صفحه وارد شوید.'
    login_manager.login_message_category = 'info'
    
    @login_manager.user_loader
    def load_user(user_id):
        from models import User
        return db.session.get(User, int(user_id))
    
    # Create tables and initialize data
    with app.app_context():
        # Import models to ensure they are registered
        import models
        import models_extended
        
        # Create all tables
        db.create_all()
        
        # Initialize RBAC data
        from rbac_routes import initialize_rbac_data
        initialize_rbac_data()
        
        # Create admin user if not exists
        from models import User, Role
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            super_admin_role = Role.query.filter_by(name='Super Admin').first()
            admin_user = User(
                username='admin',
                email='admin@example.com',
                full_name='مدیر سیستم',
                is_active=True,
                role_id=super_admin_role.id if super_admin_role else None
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
            db.session.commit()
            print("✅ کاربر admin با موفقیت ایجاد شد")
            print("📋 اطلاعات ورود:")
            print("   نام کاربری: admin")
            print("   رمز عبور: admin123")
        else:
            print("✅ کاربر admin از قبل وجود دارد.")
    
    # Register blueprints
    from routes import main_bp
    from rbac_routes import rbac_bp
    from routes_box_manufacturing import box_bp
    
    app.register_blueprint(main_bp)
    app.register_blueprint(rbac_bp)
    app.register_blueprint(box_bp)
    
    # Add template filters
    @app.template_filter('datetime')
    def datetime_filter(value):
        if value is None:
            return ""
        return value.strftime('%Y/%m/%d %H:%M')
    
    @app.template_filter('date')
    def date_filter(value):
        if value is None:
            return ""
        return value.strftime('%Y/%m/%d')
    
    @app.template_filter('currency')
    def currency_filter(value):
        if value is None:
            return "0"
        return f"{value:,.0f}"
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)

